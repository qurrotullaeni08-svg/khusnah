<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LatihanController extends Controller
{
       public function index()
    {
        $nama = "Khusnah";
        $mataKuliah = [
            "Pemrograman Web Lanjut",
            "Basis Data",
            "Algoritma & Struktur Data",
            "Sistem Operasi"
        ];

        return view('welcome_mahasiswa', compact('nama', 'mataKuliah'));
    }
}
